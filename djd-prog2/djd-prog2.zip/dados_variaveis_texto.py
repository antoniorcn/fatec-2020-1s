texto1 = "Este é um texto"

print("Texto Original :", texto1)

print("Texto em maiusculo :", texto1.upper())
print("Texto em minúsculo :", texto1.lower())
print("Texto centralizado :", texto1.center(100, '*'))
print("Quantidade de letras 'e' :", texto1.count('e'))
print("Tamanho do texto :", len(texto1))

print("Caracter na posicao 10 ao 14 :", texto1[10:15])
print("Caracter na posicao 14 ao 10 inverso :", texto1[14:9:-1])

