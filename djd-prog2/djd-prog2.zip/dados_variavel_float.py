a = 14.5

print("Numero : " + str(a))

print("Hex : ")
print(a.hex())
