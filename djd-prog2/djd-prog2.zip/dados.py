print("Exemplos de funções com numeros inteiros")
print("abs(-20) : ")
print(abs(-20))
print("hex(42895467) : ")
print(hex(42895467))
print("oct(42895467) : ")
print(oct(42895467))

print("Numero: " + str(42895467))